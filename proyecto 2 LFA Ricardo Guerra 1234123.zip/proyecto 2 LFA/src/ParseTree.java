import java.util.*;

public class ParseTree {
    private static class Node {
        String symbol;
        List<Node> children;
        int id;
        boolean expanded; // Nuevo: marca si ya se expandió

        Node(String symbol, int id) {
            this.symbol = symbol;
            this.children = new ArrayList<>();
            this.id = id;
            this.expanded = false;
        }
    }

    private Node root;
    private int nodeCounter;
    private Node currentExpansion; // Rastrea el nodo actual siendo expandido

    public ParseTree(String startSymbol) {
        this.root = new Node(startSymbol, nodeCounter++);
        this.currentExpansion = null;
    }

    public void addDerivation(String parentSymbol, List<String> production) {
        // Buscar el primer nodo no expandido con este símbolo
        Node parent = findUnexpandedNode(root, parentSymbol);

        if (parent != null && !parent.expanded) {
            parent.expanded = true;
            for (String symbol : production) {
                if (!symbol.equals("ε")) {
                    parent.children.add(new Node(symbol, nodeCounter++));
                }
            }
        }
    }

    private Node findUnexpandedNode(Node current, String symbol) {
        // Si este nodo coincide y no ha sido expandido, lo retornamos
        if (current.symbol.equals(symbol) && !current.expanded) {
            return current;
        }

        // Búsqueda en profundidad (DFS) en los hijos
        for (Node child : current.children) {
            Node found = findUnexpandedNode(child, symbol);
            if (found != null) {
                return found;
            }
        }

        return null;
    }

    public String generateDot() {
        StringBuilder sb = new StringBuilder();
        sb.append("digraph ParseTree {\n");
        sb.append("  rankdir=TB;\n");
        sb.append("  node [shape=box, style=rounded, fontname=\"Arial\"];\n");
        sb.append("  edge [fontname=\"Arial\"];\n\n");
        generateDotHelper(root, sb);
        sb.append("}\n");
        return sb.toString();
    }

    private void generateDotHelper(Node node, StringBuilder sb) {
        String label = node.symbol.replace("\"", "\\\"");

        // Color diferente para terminales vs no terminales
        if (isTerminal(node.symbol)) {
            sb.append(String.format("  node%d [label=\"%s\", fillcolor=\"lightblue\", style=\"filled,rounded\"];\n",
                    node.id, label));
        } else {
            sb.append(String.format("  node%d [label=\"%s\"];\n", node.id, label));
        }

        for (Node child : node.children) {
            sb.append(String.format("  node%d -> node%d;\n", node.id, child.id));
            generateDotHelper(child, sb);
        }
    }

    private boolean isTerminal(String symbol) {
        // Terminales conocidos
        Set<String> terminals = new HashSet<>(Arrays.asList(
                "class", "int", "void", "return", "id", "number",
                "+", "-", "*", "/", "=", "<", ">", "==", "<=", ">=", "!=",
                "(", ")", "{", "}", ";", ",", "$"
        ));
        return terminals.contains(symbol);
    }

    public Node getRoot() {
        return root;
    }
}