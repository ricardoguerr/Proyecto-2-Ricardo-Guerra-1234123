import java.util.*;

public class Lexer {
    private String input;
    private int pos;
    private int line;
    private int column;
    private int startLine;  // Para rastrear inicio de comentarios
    private int startColumn;
    private List<Token> tokens;
    private List<String> errors;
    private static final Set<String> KEYWORDS = new HashSet<>(
            Arrays.asList("class", "int", "void", "return", "if", "else", "while")
    );

    public Lexer(String input) {
        this.input = input;
        this.pos = 0;
        this.line = 1;
        this.column = 1;
        this.tokens = new ArrayList<>();
        this.errors = new ArrayList<>();
    }

    public List<Token> tokenize() {
        while (pos < input.length()) {
            char c = input.charAt(pos);

            // Espacios en blanco
            if (Character.isWhitespace(c)) {
                if (c == '\n') {
                    line++;
                    column = 1;
                } else {
                    column++;
                }
                pos++;
                continue;
            }

            // Comentarios
            if (c == '/' && pos + 1 < input.length()) {
                if (input.charAt(pos + 1) == '/') {
                    skipLineComment();
                    continue;
                } else if (input.charAt(pos + 1) == '*') {
                    if (!skipBlockComment()) {
                        // Comentario sin cerrar - ya se agregó el error
                    }
                    continue;
                }
            }

            // Identificadores y palabras clave
            if (Character.isLetter(c) || c == '_') {
                scanIdentifier();
                continue;
            }

            // Números
            if (Character.isDigit(c)) {
                scanNumber();
                continue;
            }

            // Operadores de dos caracteres
            if (pos + 1 < input.length()) {
                String twoChar = "" + c + input.charAt(pos + 1);
                if (twoChar.equals("==") || twoChar.equals("!=") ||
                        twoChar.equals("<=") || twoChar.equals(">=")) {
                    tokens.add(new Token(Token.TokenType.OPERATOR, twoChar, line, column));
                    pos += 2;
                    column += 2;
                    continue;
                }
            }

            // Operadores y símbolos de un carácter
            if ("+-*/=<>!".indexOf(c) != -1) {
                tokens.add(new Token(Token.TokenType.OPERATOR, String.valueOf(c), line, column));
                pos++;
                column++;
                continue;
            }

            if ("(){}[];,".indexOf(c) != -1) {
                tokens.add(new Token(Token.TokenType.SYMBOL, String.valueOf(c), line, column));
                pos++;
                column++;
                continue;
            }

            // Carácter ilegal
            errors.add(String.format("Error léxico en línea %d, columna %d: carácter ilegal '%c'",
                    line, column, c));
            pos++;
            column++;
        }

        tokens.add(new Token(Token.TokenType.EOF, "$", line, column));
        return tokens;
    }

    private void skipLineComment() {
        while (pos < input.length() && input.charAt(pos) != '\n') {
            pos++;
            column++;
        }
    }

    private boolean skipBlockComment() {
        startLine = line;
        startColumn = column;
        pos += 2;
        column += 2;

        while (pos < input.length()) {
            if (pos + 1 < input.length() && input.charAt(pos) == '*' && input.charAt(pos + 1) == '/') {
                pos += 2;
                column += 2;
                return true;  // Comentario cerrado correctamente
            }
            if (input.charAt(pos) == '\n') {
                line++;
                column = 1;
            } else {
                column++;
            }
            pos++;
        }

        // Si llegamos aquí, el comentario no se cerró
        errors.add(String.format("Error léxico en línea %d, columna %d: comentario de bloque sin cerrar (iniciado en línea %d, columna %d)",
                startLine, startColumn, line, column));
        return false;
    }

    private void scanIdentifier() {
        int startCol = column;
        StringBuilder sb = new StringBuilder();
        while (pos < input.length() && (Character.isLetterOrDigit(input.charAt(pos)) || input.charAt(pos) == '_')) {
            sb.append(input.charAt(pos));
            pos++;
            column++;
        }
        String value = sb.toString();
        Token.TokenType type = KEYWORDS.contains(value) ? Token.TokenType.KEYWORD : Token.TokenType.ID;
        tokens.add(new Token(type, value, line, startCol));
    }

    private void scanNumber() {
        int startCol = column;
        StringBuilder sb = new StringBuilder();
        while (pos < input.length() && Character.isDigit(input.charAt(pos))) {
            sb.append(input.charAt(pos));
            pos++;
            column++;
        }
        tokens.add(new Token(Token.TokenType.NUMBER, sb.toString(), line, startCol));
    }

    public List<String> getErrors() {
        return errors;
    }

    public int getTotalLines() {
        return line;
    }
}