import java.util.*;

public class Parser {
    private List<Token> tokens;
    private int currentTokenIndex;
    private Grammar grammar;
    private ParseTree parseTree;
    private List<String> errors;
    private Stack<String> stack;

    public Parser(List<Token> tokens, Grammar grammar) {
        this.tokens = tokens;
        this.currentTokenIndex = 0;
        this.grammar = grammar;
        this.parseTree = new ParseTree("Prog");
        this.errors = new ArrayList<>();
        this.stack = new Stack<>();
    }

    public boolean parse() {
        stack.push("$");
        stack.push("Prog");

        Token currentToken = tokens.get(currentTokenIndex);

        while (!stack.isEmpty()) {
            String top = stack.pop();
            String terminal = getTerminalFromToken(currentToken);

            // Si el tope es terminal
            if (grammar.getTerminals().contains(top)) {
                if (top.equals("$")) {
                    if (terminal.equals("$")) {
                        return errors.isEmpty();
                    } else {
                        errors.add(String.format("Error sintáctico en línea %d, columna %d: se esperaba fin de archivo",
                                currentToken.getLine(), currentToken.getColumn()));
                        return false;
                    }
                } else if (top.equals(terminal) || (top.equals("id") && currentToken.getType() == Token.TokenType.ID) ||
                        (top.equals("number") && currentToken.getType() == Token.TokenType.NUMBER)) {
                    // NO agregar al árbol aquí - los terminales ya están en el árbol
                    currentTokenIndex++;
                    if (currentTokenIndex < tokens.size()) {
                        currentToken = tokens.get(currentTokenIndex);
                    }
                } else {
                    errors.add(String.format("Error sintáctico en línea %d, columna %d: se esperaba '%s', se encontró '%s'",
                            currentToken.getLine(), currentToken.getColumn(), top, currentToken.getValue()));
                    currentTokenIndex++;
                    if (currentTokenIndex < tokens.size()) {
                        currentToken = tokens.get(currentTokenIndex);
                    }
                }
            }
            // Si el tope es no terminal
            else if (grammar.getNonTerminals().contains(top)) {
                Map<String, List<String>> row = grammar.getParsingTable().get(top);
                List<String> production = null;

                if (row.containsKey(terminal)) {
                    production = row.get(terminal);
                } else if (currentToken.getType() == Token.TokenType.ID && row.containsKey("id")) {
                    production = row.get("id");
                } else if (currentToken.getType() == Token.TokenType.NUMBER && row.containsKey("number")) {
                    production = row.get("number");
                }

                if (production != null) {
                    // SOLO agregar al árbol cuando expandimos un NO TERMINAL
                    parseTree.addDerivation(top, production);

                    // Apilar producción en orden inverso
                    if (!production.get(0).equals("ε")) {
                        for (int i = production.size() - 1; i >= 0; i--) {
                            stack.push(production.get(i));
                        }
                    }
                } else {
                    errors.add(String.format("Error sintáctico en línea %d, columna %d: no hay producción para M[%s, %s]",
                            currentToken.getLine(), currentToken.getColumn(), top, terminal));
                    currentTokenIndex++;
                    if (currentTokenIndex < tokens.size()) {
                        currentToken = tokens.get(currentTokenIndex);
                    } else {
                        break;
                    }
                }
            }
        }

        return errors.isEmpty();
    }

    private String getTerminalFromToken(Token token) {
        if (token.getType() == Token.TokenType.EOF) {
            return "$";
        } else if (token.getType() == Token.TokenType.ID) {
            return "id";
        } else if (token.getType() == Token.TokenType.NUMBER) {
            return "number";
        } else {
            return token.getValue();
        }
    }

    public ParseTree getParseTree() {
        return parseTree;
    }

    public List<String> getErrors() {
        return errors;
    }
}