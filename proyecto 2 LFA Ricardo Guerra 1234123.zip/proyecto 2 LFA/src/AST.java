import java.util.*;

/**
 * AST (Abstract Syntax Tree) - Árbol de Sintaxis Abstracta
 */
public class AST {

    /**
     * Clase base para todos los nodos del AST
     */
    public static abstract class ASTNode {
        public abstract String toLabel();
    }

    public static class ProgramNode extends ASTNode {
        public ClassNode classDecl;
        public ProgramNode(ClassNode classDecl) { this.classDecl = classDecl; }
        public String toLabel() { return "Program"; }
    }

    public static class ClassNode extends ASTNode {
        public String name;
        public List<ASTNode> members;
        public ClassNode(String name) { this.name = name; this.members = new ArrayList<>(); }
        public void addMember(ASTNode member) { members.add(member); }
        public String toLabel() { return "Class: " + name; }
    }

    public static class VarDeclNode extends ASTNode {
        public String type;
        public String name;
        public VarDeclNode(String type, String name) { this.type = type; this.name = name; }
        public String toLabel() { return "Var: " + type + " " + name; }
    }

    public static class MethodDeclNode extends ASTNode {
        public String returnType;
        public String name;
        public List<VarDeclNode> parameters;
        public BlockNode body;
        public MethodDeclNode(String returnType, String name) {
            this.returnType = returnType;
            this.name = name;
            this.parameters = new ArrayList<>();
        }
        public void addParameter(VarDeclNode param) { parameters.add(param); }
        public void setBody(BlockNode body) { this.body = body; }
        public String toLabel() { return "Method: " + returnType + " " + name + "()"; }
    }

    public static class BlockNode extends ASTNode {
        public List<ASTNode> statements;
        public BlockNode() { this.statements = new ArrayList<>(); }
        public void addStatement(ASTNode stmt) { statements.add(stmt); }
        public String toLabel() { return "Block"; }
    }

    public static class AssignNode extends ASTNode {
        public String varName;
        public ASTNode expression;
        public AssignNode(String varName, ASTNode expression) {
            this.varName = varName;
            this.expression = expression;
        }
        public String toLabel() { return "Assign: " + varName; }
    }

    public static class BinaryOpNode extends ASTNode {
        public String operator;
        public ASTNode left;
        public ASTNode right;
        public BinaryOpNode(String operator, ASTNode left, ASTNode right) {
            this.operator = operator;
            this.left = left;
            this.right = right;
        }
        public String toLabel() { return "Op: " + operator; }
    }

    public static class NumberNode extends ASTNode {
        public String value;
        public NumberNode(String value) { this.value = value; }
        public String toLabel() { return value; }
    }

    public static class IdentifierNode extends ASTNode {
        public String name;
        public IdentifierNode(String name) { this.name = name; }
        public String toLabel() { return name; }
    }

    public static class CallNode extends ASTNode {
        public String functionName;
        public List<ASTNode> arguments;
        public CallNode(String functionName) {
            this.functionName = functionName;
            this.arguments = new ArrayList<>();
        }
        public void addArgument(ASTNode arg) { arguments.add(arg); }
        public String toLabel() { return "Call: " + functionName + "()"; }
    }

    public static class ReturnNode extends ASTNode {
        public ASTNode expression;
        public ReturnNode(ASTNode expression) { this.expression = expression; }
        public String toLabel() { return "Return"; }
    }

    /**
     * Genera el archivo .dot completo
     */
    public static String generateDot(ASTNode root) {
        StringBuilder sb = new StringBuilder();
        sb.append("digraph AST {\n");
        sb.append("  rankdir=TB;\n");
        sb.append("  node [fontname=\"Arial\"];\n");
        sb.append("  edge [fontname=\"Arial\", fontsize=10];\n\n");

        int[] nodeCounter = new int[]{0};
        generateDotHelper(root, sb, nodeCounter);

        sb.append("}\n");
        return sb.toString();
    }

    private static int generateDotHelper(ASTNode node, StringBuilder sb, int[] counter) {
        int myId = counter[0]++;

        // Generar el nodo actual
        String label = node.toLabel().replace("\"", "\\\"");
        String style = getNodeStyle(node);
        sb.append(String.format("  node%d [label=\"%s\"%s];\n", myId, label, style));

        // Generar aristas y llamar recursivamente a los hijos
        if (node instanceof ProgramNode) {
            ProgramNode prog = (ProgramNode) node;
            if (prog.classDecl != null) {
                int childId = generateDotHelper(prog.classDecl, sb, counter);
                sb.append(String.format("  node%d -> node%d;\n", myId, childId));
            }
        } else if (node instanceof ClassNode) {
            ClassNode cls = (ClassNode) node;
            for (ASTNode member : cls.members) {
                int childId = generateDotHelper(member, sb, counter);
                sb.append(String.format("  node%d -> node%d;\n", myId, childId));
            }
        } else if (node instanceof MethodDeclNode) {
            MethodDeclNode method = (MethodDeclNode) node;
            for (VarDeclNode param : method.parameters) {
                int childId = generateDotHelper(param, sb, counter);
                sb.append(String.format("  node%d -> node%d [label=\"param\"];\n", myId, childId));
            }
            if (method.body != null) {
                int childId = generateDotHelper(method.body, sb, counter);
                sb.append(String.format("  node%d -> node%d [label=\"body\"];\n", myId, childId));
            }
        } else if (node instanceof BlockNode) {
            BlockNode block = (BlockNode) node;
            for (ASTNode stmt : block.statements) {
                int childId = generateDotHelper(stmt, sb, counter);
                sb.append(String.format("  node%d -> node%d;\n", myId, childId));
            }
        } else if (node instanceof AssignNode) {
            AssignNode assign = (AssignNode) node;
            if (assign.expression != null) {
                int childId = generateDotHelper(assign.expression, sb, counter);
                sb.append(String.format("  node%d -> node%d;\n", myId, childId));
            }
        } else if (node instanceof BinaryOpNode) {
            BinaryOpNode binOp = (BinaryOpNode) node;
            if (binOp.left != null) {
                int leftId = generateDotHelper(binOp.left, sb, counter);
                sb.append(String.format("  node%d -> node%d [label=\"L\"];\n", myId, leftId));
            }
            if (binOp.right != null) {
                int rightId = generateDotHelper(binOp.right, sb, counter);
                sb.append(String.format("  node%d -> node%d [label=\"R\"];\n", myId, rightId));
            }
        } else if (node instanceof ReturnNode) {
            ReturnNode ret = (ReturnNode) node;
            if (ret.expression != null) {
                int childId = generateDotHelper(ret.expression, sb, counter);
                sb.append(String.format("  node%d -> node%d;\n", myId, childId));
            }
        } else if (node instanceof CallNode) {
            CallNode call = (CallNode) node;
            for (ASTNode arg : call.arguments) {
                int childId = generateDotHelper(arg, sb, counter);
                sb.append(String.format("  node%d -> node%d [label=\"arg\"];\n", myId, childId));
            }
        }

        return myId;
    }

    private static String getNodeStyle(ASTNode node) {
        if (node instanceof ProgramNode) return ", style=filled, fillcolor=\"lightblue\"";
        if (node instanceof ClassNode) return ", style=filled, fillcolor=\"lightgreen\"";
        if (node instanceof MethodDeclNode) return ", style=filled, fillcolor=\"lightyellow\"";
        if (node instanceof VarDeclNode) return ", shape=box";
        if (node instanceof AssignNode) return ", style=filled, fillcolor=\"lightcoral\"";
        if (node instanceof BinaryOpNode) return ", shape=circle, style=filled, fillcolor=\"lightgray\"";
        if (node instanceof NumberNode) return ", shape=ellipse, style=filled, fillcolor=\"lightpink\"";
        if (node instanceof IdentifierNode) return ", shape=ellipse";
        if (node instanceof CallNode) return ", style=filled, fillcolor=\"lightcyan\"";
        if (node instanceof ReturnNode) return ", style=filled, fillcolor=\"orange\"";
        return "";
    }
}