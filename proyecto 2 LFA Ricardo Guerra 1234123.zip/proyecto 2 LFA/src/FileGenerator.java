import java.io.*;
import java.util.*;

public class FileGenerator {

    private static String repeat(String str, int count) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < count; i++) {
            result.append(str);
        }
        return result.toString();
    }

    public static void generateErrorsFile(List<String> lexerErrors, List<String> parserErrors) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("errores.txt"))) {
            writer.println("=== REPORTE DE ERRORES ===\n");

            if (!lexerErrors.isEmpty()) {
                writer.println("--- Errores Léxicos ---");
                for (String error : lexerErrors) {
                    writer.println(error);
                }
                writer.println();
            }

            if (!parserErrors.isEmpty()) {
                writer.println("--- Errores Sintácticos ---");
                for (String error : parserErrors) {
                    writer.println(error);
                }
                writer.println();
            }

            if (lexerErrors.isEmpty() && parserErrors.isEmpty()) {
                writer.println("No se encontraron errores.");
            }

            writer.println("\n=== FIN DEL REPORTE ===");
        } catch (IOException e) {
            System.err.println("Error al generar errores.txt: " + e.getMessage());
        }
    }

    public static void generateParsingTableFile(Grammar grammar) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("tabla_transicion.txt"))) {
            writer.println("=== TABLA DE TRANSICIÓN LL(1) ===\n");

            Map<String, Map<String, List<String>>> table = grammar.getParsingTable();
            Set<String> terminals = new TreeSet<>(grammar.getTerminals());
            terminals.remove("ε");

            // Encabezado
            writer.printf("%-20s", "No Terminal");
            for (String terminal : terminals) {
                writer.printf("%-20s", terminal);
            }
            writer.println();
            writer.println(repeat("-", 20 + terminals.size() * 20));

            // Filas
            for (String nonTerminal : grammar.getNonTerminals()) {
                writer.printf("%-20s", nonTerminal);
                for (String terminal : terminals) {
                    List<String> production = table.get(nonTerminal).get(terminal);
                    if (production != null) {
                        String prodStr = String.join(" ", production);
                        writer.printf("%-20s", prodStr.length() > 18 ? prodStr.substring(0, 17) + "..." : prodStr);
                    } else {
                        writer.printf("%-20s", "-");
                    }
                }
                writer.println();
            }

            writer.println("\n=== CONJUNTOS FIRST ===\n");
            for (String nt : grammar.getNonTerminals()) {
                writer.printf("FIRST(%s) = %s\n", nt, grammar.getFirstSets().get(nt));
            }

            writer.println("\n=== CONJUNTOS FOLLOW ===\n");
            for (String nt : grammar.getNonTerminals()) {
                writer.printf("FOLLOW(%s) = %s\n", nt, grammar.getFollowSets().get(nt));
            }

            if (!grammar.getConflicts().isEmpty()) {
                writer.println("\n=== CONFLICTOS DETECTADOS ===\n");
                for (String conflict : grammar.getConflicts()) {
                    writer.println(conflict);
                }
            } else {
                writer.println("\n=== La gramática es LL(1) - No hay conflictos ===");
            }

        } catch (IOException e) {
            System.err.println("Error al generar tabla_transicion.txt: " + e.getMessage());
        }
    }

    public static void generateParseTreeFile(ParseTree parseTree) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("arbol.dot"))) {
            writer.println(parseTree.generateDot());
        } catch (IOException e) {
            System.err.println("Error al generar arbol.dot: " + e.getMessage());
        }
    }

    public static void generateASTFile(AST.ASTNode astRoot) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("ast.dot"))) {
            String dotContent = AST.generateDot(astRoot);
            writer.println(dotContent);
        } catch (IOException e) {
            System.err.println("Error al generar ast.dot: " + e.getMessage());
        }
    }
}