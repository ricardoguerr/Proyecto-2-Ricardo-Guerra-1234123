import java.util.*;

public class Grammar {
    private Map<String, List<List<String>>> productions;
    private Map<String, Set<String>> firstSets;
    private Map<String, Set<String>> followSets;
    private Map<String, Map<String, List<String>>> parsingTable;
    private Set<String> terminals;
    private Set<String> nonTerminals;
    private List<String> conflicts;

    public Grammar() {
        productions = new LinkedHashMap<>();
        firstSets = new HashMap<>();
        followSets = new HashMap<>();
        parsingTable = new HashMap<>();
        terminals = new HashSet<>();
        nonTerminals = new HashSet<>();
        conflicts = new ArrayList<>();

        initializeGrammar();
        computeFirstSets();
        computeFollowSets();
        buildParsingTable();
    }

    private void initializeGrammar() {
        // Gramática factorizada para LL(1) con operadores relacionales
        addProduction("Prog", Arrays.asList("ClassDecl"));

        addProduction("ClassDecl", Arrays.asList("class", "id", "{", "MemberList", "}"));

        addProduction("MemberList", Arrays.asList("Member", "MemberList"));
        addProduction("MemberList", Arrays.asList("ε"));

        addProduction("Member", Arrays.asList("Type", "id", "MemberP"));

        addProduction("MemberP", Arrays.asList(";"));
        addProduction("MemberP", Arrays.asList("(", "ParamList", ")", "Block"));

        addProduction("ParamList", Arrays.asList("Param", "ParamRest"));
        addProduction("ParamList", Arrays.asList("ε"));

        addProduction("ParamRest", Arrays.asList(",", "Param", "ParamRest"));
        addProduction("ParamRest", Arrays.asList("ε"));

        addProduction("Param", Arrays.asList("Type", "id"));

        addProduction("Block", Arrays.asList("{", "StmtList", "}"));

        addProduction("StmtList", Arrays.asList("Stmt", "StmtList"));
        addProduction("StmtList", Arrays.asList("ε"));

        addProduction("Stmt", Arrays.asList("Type", "id", ";"));
        addProduction("Stmt", Arrays.asList("id", "StmtP"));
        addProduction("Stmt", Arrays.asList("return", "ReturnP"));

        addProduction("StmtP", Arrays.asList("=", "Expr", ";"));
        addProduction("StmtP", Arrays.asList("(", "ArgList", ")", ";"));

        addProduction("ReturnP", Arrays.asList("Expr", ";"));
        addProduction("ReturnP", Arrays.asList(";"));

        addProduction("ArgList", Arrays.asList("Expr", "ArgRest"));
        addProduction("ArgList", Arrays.asList("ε"));

        addProduction("ArgRest", Arrays.asList(",", "Expr", "ArgRest"));
        addProduction("ArgRest", Arrays.asList("ε"));

        // Expresiones con operadores relacionales y aritméticos
        addProduction("Expr", Arrays.asList("Term", "ExprP"));

        addProduction("ExprP", Arrays.asList("+", "Term", "ExprP"));
        addProduction("ExprP", Arrays.asList("-", "Term", "ExprP"));
        addProduction("ExprP", Arrays.asList("<", "Term", "ExprP"));
        addProduction("ExprP", Arrays.asList(">", "Term", "ExprP"));
        addProduction("ExprP", Arrays.asList("==", "Term", "ExprP"));
        addProduction("ExprP", Arrays.asList("!=", "Term", "ExprP"));
        addProduction("ExprP", Arrays.asList("<=", "Term", "ExprP"));
        addProduction("ExprP", Arrays.asList(">=", "Term", "ExprP"));
        addProduction("ExprP", Arrays.asList("ε"));

        addProduction("Term", Arrays.asList("Factor", "TermP"));

        addProduction("TermP", Arrays.asList("*", "Factor", "TermP"));
        addProduction("TermP", Arrays.asList("/", "Factor", "TermP"));
        addProduction("TermP", Arrays.asList("ε"));

        addProduction("Factor", Arrays.asList("id", "FactorP"));
        addProduction("Factor", Arrays.asList("number"));
        addProduction("Factor", Arrays.asList("(", "Expr", ")"));

        addProduction("FactorP", Arrays.asList("(", "ArgList", ")"));
        addProduction("FactorP", Arrays.asList("ε"));

        addProduction("Type", Arrays.asList("int"));
        addProduction("Type", Arrays.asList("void"));

        // Terminales
        terminals.addAll(Arrays.asList("class", "int", "void", "return", "id", "number",
                "+", "-", "*", "/", "=", "<", ">", "==", "<=", ">=", "!=",
                "(", ")", "{", "}", ";", ",", "$", "ε"));

        nonTerminals.addAll(productions.keySet());
    }

    private void addProduction(String nonTerminal, List<String> production) {
        productions.putIfAbsent(nonTerminal, new ArrayList<>());
        productions.get(nonTerminal).add(production);
    }

    private void computeFirstSets() {
        for (String nt : nonTerminals) {
            firstSets.put(nt, new HashSet<>());
        }

        boolean changed = true;
        while (changed) {
            changed = false;
            for (String nonTerminal : nonTerminals) {
                Set<String> currentFirst = firstSets.get(nonTerminal);
                int sizeBefore = currentFirst.size();

                for (List<String> production : productions.get(nonTerminal)) {
                    Set<String> firstOfProduction = computeFirstOfProduction(production);
                    currentFirst.addAll(firstOfProduction);
                }

                if (currentFirst.size() > sizeBefore) {
                    changed = true;
                }
            }
        }
    }

    private Set<String> computeFirstOfProduction(List<String> production) {
        Set<String> result = new HashSet<>();

        if (production.size() == 1 && production.get(0).equals("ε")) {
            result.add("ε");
            return result;
        }

        for (String symbol : production) {
            if (terminals.contains(symbol)) {
                result.add(symbol);
                break;
            } else if (nonTerminals.contains(symbol)) {
                Set<String> firstOfSymbol = firstSets.get(symbol);
                result.addAll(firstOfSymbol);
                result.remove("ε");

                if (!firstOfSymbol.contains("ε")) {
                    break;
                }
            }
        }

        boolean allHaveEpsilon = true;
        for (String symbol : production) {
            if (terminals.contains(symbol) ||
                    (nonTerminals.contains(symbol) && !firstSets.get(symbol).contains("ε"))) {
                allHaveEpsilon = false;
                break;
            }
        }

        if (allHaveEpsilon) {
            result.add("ε");
        }

        return result;
    }

    private void computeFollowSets() {
        for (String nt : nonTerminals) {
            followSets.put(nt, new HashSet<>());
        }

        followSets.get("Prog").add("$");

        boolean changed = true;
        while (changed) {
            changed = false;

            for (String nonTerminal : nonTerminals) {
                for (List<String> production : productions.get(nonTerminal)) {
                    for (int i = 0; i < production.size(); i++) {
                        String symbol = production.get(i);

                        if (nonTerminals.contains(symbol)) {
                            Set<String> currentFollow = followSets.get(symbol);
                            int sizeBefore = currentFollow.size();

                            List<String> beta = production.subList(i + 1, production.size());
                            Set<String> firstOfBeta = computeFirstOfProduction(beta);

                            currentFollow.addAll(firstOfBeta);
                            currentFollow.remove("ε");

                            if (firstOfBeta.contains("ε") || beta.isEmpty()) {
                                currentFollow.addAll(followSets.get(nonTerminal));
                            }

                            if (currentFollow.size() > sizeBefore) {
                                changed = true;
                            }
                        }
                    }
                }
            }
        }
    }

    private void buildParsingTable() {
        for (String nt : nonTerminals) {
            parsingTable.put(nt, new HashMap<>());
        }

        for (String nonTerminal : nonTerminals) {
            for (List<String> production : productions.get(nonTerminal)) {
                Set<String> firstOfProduction = computeFirstOfProduction(production);

                for (String terminal : firstOfProduction) {
                    if (!terminal.equals("ε")) {
                        addToParsingTable(nonTerminal, terminal, production);
                    }
                }

                if (firstOfProduction.contains("ε")) {
                    for (String terminal : followSets.get(nonTerminal)) {
                        addToParsingTable(nonTerminal, terminal, production);
                    }
                }
            }
        }
    }

    private void addToParsingTable(String nonTerminal, String terminal, List<String> production) {
        Map<String, List<String>> row = parsingTable.get(nonTerminal);

        if (row.containsKey(terminal)) {
            List<String> existing = row.get(terminal);
            if (!existing.equals(production)) {
                conflicts.add(String.format("Conflicto en [%s, %s]: %s vs %s",
                        nonTerminal, terminal,
                        String.join(" ", existing),
                        String.join(" ", production)));
            }
        } else {
            row.put(terminal, new ArrayList<>(production));
        }
    }

    public Map<String, List<List<String>>> getProductions() {
        return productions;
    }

    public Map<String, Map<String, List<String>>> getParsingTable() {
        return parsingTable;
    }

    public List<String> getConflicts() {
        return conflicts;
    }

    public Set<String> getTerminals() {
        return terminals;
    }

    public Set<String> getNonTerminals() {
        return nonTerminals;
    }

    public Map<String, Set<String>> getFirstSets() {
        return firstSets;
    }

    public Map<String, Set<String>> getFollowSets() {
        return followSets;
    }
}