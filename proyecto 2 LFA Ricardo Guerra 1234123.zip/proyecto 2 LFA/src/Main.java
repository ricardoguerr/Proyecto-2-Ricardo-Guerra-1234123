import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;

public class Main extends JFrame {
    private JTextArea inputArea;
    private JTextArea outputArea;
    private JButton analyzeButton;
    private JButton loadButton;
    private JButton clearButton;

    public Main() {
        setTitle("Analizador Sintáctico - Proyecto 2");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        // Panel principal con BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Panel superior con título
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(41, 128, 185));
        JLabel titleLabel = new JLabel("Analizador Sintáctico Avanzado");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);

        // Panel de entrada (izquierda)
        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Código Fuente (programa.txt)",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 12)
        ));

        inputArea = new JTextArea();
        inputArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        inputArea.setTabSize(4);
        inputArea.setText("class Demo {\n" +
                "    int x;\n" +
                "    int y;\n" +
                "    \n" +
                "    int suma(int a, int b) {\n" +
                "        return a + b;\n" +
                "    }\n" +
                "    \n" +
                "    void main() {\n" +
                "        x = 2 + 3 * (4 + 5);\n" +
                "        y = suma(x, 10);\n" +
                "        return;\n" +
                "    }\n" +
                "}");

        JScrollPane inputScroll = new JScrollPane(inputArea);
        inputPanel.add(inputScroll, BorderLayout.CENTER);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));

        loadButton = new JButton("Cargar Archivo");
        loadButton.setFont(new Font("Arial", Font.PLAIN, 12));
        loadButton.addActionListener(e -> loadFile());

        analyzeButton = new JButton("Analizar");
        analyzeButton.setFont(new Font("Arial", Font.BOLD, 14));
        analyzeButton.setBackground(new Color(46, 204, 113));
        analyzeButton.setForeground(Color.WHITE);
        analyzeButton.setFocusPainted(false);
        analyzeButton.addActionListener(e -> analyze());

        clearButton = new JButton("Limpiar");
        clearButton.setFont(new Font("Arial", Font.PLAIN, 12));
        clearButton.addActionListener(e -> clear());

        buttonPanel.add(loadButton);
        buttonPanel.add(analyzeButton);
        buttonPanel.add(clearButton);

        inputPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Panel de salida (derecha)
        JPanel outputPanel = new JPanel(new BorderLayout(5, 5));
        outputPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Resultados del Análisis",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 12)
        ));

        outputArea = new JTextArea();
        outputArea.setFont(new Font("Consolas", Font.PLAIN, 11));
        outputArea.setEditable(false);

        JScrollPane outputScroll = new JScrollPane(outputArea);
        outputPanel.add(outputScroll, BorderLayout.CENTER);

        // Split pane para dividir entrada y salida
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, inputPanel, outputPanel);
        splitPane.setDividerLocation(550);
        splitPane.setResizeWeight(0.5);

        // Agregar componentes al panel principal
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(splitPane, BorderLayout.CENTER);

        add(mainPanel);
    }

    private void loadFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().toLowerCase().endsWith(".txt");
            }
            public String getDescription() {
                return "Archivos de texto (*.txt)";
            }
        });

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                StringBuilder content = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    content.append(line).append("\n");
                }
                inputArea.setText(content.toString());
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                        "Error al cargar el archivo: " + e.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void analyze() {
        String input = inputArea.getText();
        if (input.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "ingrese código fuente para analizar.",
                    "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        outputArea.setText("Analizando...\n\n");

        try {
            // Fase 1: Análisis Léxico
            Lexer lexer = new Lexer(input);
            List<Token> tokens = lexer.tokenize();

            StringBuilder output = new StringBuilder();
            output.append("═══════════════════════════════════════════════════════\n");
            output.append("           ANÁLISIS LÉXICO - TOKENS DETECTADOS\n");
            output.append("═══════════════════════════════════════════════════════\n\n");

            // Clasificación de tokens
            Map<String, Integer> tokenStats = new HashMap<>();
            tokenStats.put("variables", 0);
            tokenStats.put("funciones", 0);
            tokenStats.put("operadores", 0);
            tokenStats.put("simbolos", 0);

            Set<String> variables = new HashSet<>();
            Set<String> funciones = new HashSet<>();

            for (int i = 0; i < tokens.size() - 1; i++) {
                Token token = tokens.get(i);
                output.append(String.format("%-15s %-15s Línea: %-3d Columna: %-3d\n",
                        token.getCategory(), "'" + token.getValue() + "'",
                        token.getLine(), token.getColumn()));

                // Clasificación semántica básica
                if (token.getType() == Token.TokenType.ID) {
                    // Detectar si es función (seguido de paréntesis)
                    if (i + 1 < tokens.size() && tokens.get(i + 1).getValue().equals("(")) {
                        funciones.add(token.getValue());
                        tokenStats.put("funciones", tokenStats.get("funciones") + 1);
                    } else {
                        variables.add(token.getValue());
                        tokenStats.put("variables", tokenStats.get("variables") + 1);
                    }
                } else if (token.getType() == Token.TokenType.OPERATOR) {
                    tokenStats.put("operadores", tokenStats.get("operadores") + 1);
                } else if (token.getType() == Token.TokenType.SYMBOL) {
                    tokenStats.put("simbolos", tokenStats.get("simbolos") + 1);
                }
            }

            output.append("\n═══════════════════════════════════════════════════════\n");
            output.append("                    ESTADÍSTICAS\n");
            output.append("═══════════════════════════════════════════════════════\n\n");
            output.append(String.format("Total de líneas procesadas: %d\n", lexer.getTotalLines()));
            output.append(String.format("Total de tokens: %d\n", tokens.size() - 1));
            output.append(String.format("Variables detectadas: %d %s\n", variables.size(), variables));
            output.append(String.format("Funciones/métodos: %d %s\n", funciones.size(), funciones));
            output.append(String.format("Operadores: %d\n", tokenStats.get("operadores")));
            output.append(String.format("Símbolos: %d\n", tokenStats.get("simbolos")));

            // Errores léxicos
            if (!lexer.getErrors().isEmpty()) {
                output.append("\nERRORES LÉXICOS DETECTADOS:\n");
                for (String error : lexer.getErrors()) {
                    output.append("  • " + error + "\n");
                }
            }

            // Fase 2: Generación de Gramática y Tabla LL(1)
            output.append("\n═══════════════════════════════════════════════════════\n");
            output.append("         GENERACIÓN DE TABLA DE TRANSICIÓN LL(1)\n");
            output.append("═══════════════════════════════════════════════════════\n\n");

            Grammar grammar = new Grammar();

            if (!grammar.getConflicts().isEmpty()) {
                output.append("ERRORES DETECTADOS EN LA GRAMÁTICA:\n");
                for (String conflict : grammar.getConflicts()) {
                    output.append("  • " + conflict + "\n");
                }
                output.append("\nLa gramática NO es LL(1).\n");
            } else {
                output.append("La gramática es LL(1)\n");
                output.append("Tabla de transición generada .\n");
            }

            // Fase 3: Análisis Sintáctico
            output.append("\n═══════════════════════════════════════════════════════\n");
            output.append("              ANÁLISIS SINTÁCTICO PREDICTIVO\n");
            output.append("═══════════════════════════════════════════════════════\n\n");

            Parser parser = new Parser(tokens, grammar);
            boolean success = parser.parse();

            if (success) {
                output.append("Análisis sintáctico completado exitosamente.\n");
                output.append("El programa es sintácticamente correcto.\n");
            } else {
                output.append("ERRORES SINTÁCTICOS DETECTADOS:\n");
                for (String error : parser.getErrors()) {
                    output.append("  • " + error + "\n");
                }
            }

            // Fase 4: Construcción del AST
            output.append("\n═══════════════════════════════════════════════════════\n");
            output.append("         CONSTRUCCIÓN DEL ÁRBOL SINTÁCTICO ABSTRACTO\n");
            output.append("═══════════════════════════════════════════════════════\n\n");

            AST.ASTNode astRoot = null;
            if (success) {
                try {
                    ASTBuilder astBuilder = new ASTBuilder(tokens);
                    astRoot = astBuilder.buildAST();
                    output.append("AST construido .\n");
                } catch (Exception e) {
                    output.append("Error al construir el AST: " + e.getMessage() + "\n");
                }
            } else {
                output.append("No se puede construir el AST debido a errores sintácticos.\n");
            }

            // Fase 5: Generación de Archivos
            output.append("\n═══════════════════════════════════════════════════════\n");
            output.append("              GENERACIÓN DE ARCHIVOS\n");
            output.append("═══════════════════════════════════════════════════════\n\n");

            FileGenerator.generateErrorsFile(lexer.getErrors(), parser.getErrors());
            output.append(" Archivo 'errores.txt' generado.\n");

            FileGenerator.generateParsingTableFile(grammar);
            output.append(" Archivo 'tabla_transicion.txt' generado.\n");

            FileGenerator.generateParseTreeFile(parser.getParseTree());
            output.append(" Archivo 'arbol.dot' generado ).\n");

            if (astRoot != null) {
                FileGenerator.generateASTFile(astRoot);
                output.append("Archivo 'ast.dot' generado (árbol sintáctico abstracto).\n");
            }

            output.append("\n═══════════════════════════════════════════════════════\n");
            output.append("                  ANÁLISIS COMPLETADO\n");
            output.append("═══════════════════════════════════════════════════════\n");

            outputArea.setText(output.toString());

            String message = "Análisis completado.\n\n" +
                    "Archivos generados:\n" +
                    "  errores.txt\n" +
                    "  tabla_transicion.txt\n" +
                    "  arbol.dot (árbol de derivación)\n";

            if (astRoot != null) {
                message += "  • ast.dot (árbol sintáctico abstracto)\n";
            }

            message += "\nPara ver los árboles:\n" +
                    "dot -Tpng arbol.dot -o arbol.png\n" +
                    "dot -Tpng ast.dot -o ast.png";

            JOptionPane.showMessageDialog(this,
                    message,
                    "Análisis Completado",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            outputArea.setText("Error durante el análisis:\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    private void clear() {
        inputArea.setText("");
        outputArea.setText("");
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            Main frame = new Main();
            frame.setVisible(true);
        });
    }
}