public class Token {
    public enum TokenType {
        KEYWORD, ID, NUMBER, OPERATOR, SYMBOL, EOF, EPSILON
    }

    private TokenType type;
    private String value;
    private int line;
    private int column;

    public Token(TokenType type, String value, int line, int column) {
        this.type = type;
        this.value = value;
        this.line = line;
        this.column = column;
    }

    public TokenType getType() {
        return type;
    }

    public String getValue() {
        return value;
    }

    public int getLine() {
        return line;
    }

    public int getColumn() {
        return column;
    }

    @Override
    public String toString() {
        return String.format("%s('%s', %d:%d)", type, value, line, column);
    }

    public String getCategory() {
        switch (type) {
            case KEYWORD:
                return "Palabra clave";
            case ID:
                return "Identificador";
            case NUMBER:
                return "Número";
            case OPERATOR:
                return "Operador";
            case SYMBOL:
                return "Símbolo";
            default:
                return "Otro";
        }
    }
}