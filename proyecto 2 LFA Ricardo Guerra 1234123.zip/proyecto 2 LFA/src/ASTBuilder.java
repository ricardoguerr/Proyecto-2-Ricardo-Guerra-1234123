import java.util.*;

/**
 * ASTBuilder - Construye el AST a partir de los tokens
 */
public class ASTBuilder {
    private List<Token> tokens;
    private int currentIndex;

    public ASTBuilder(List<Token> tokens) {
        this.tokens = tokens;
        this.currentIndex = 0;
    }

    private Token current() {
        if (currentIndex < tokens.size()) {
            return tokens.get(currentIndex);
        }
        return tokens.get(tokens.size() - 1);
    }

    private Token peek(int offset) {
        int index = currentIndex + offset;
        if (index < tokens.size()) {
            return tokens.get(index);
        }
        return tokens.get(tokens.size() - 1);
    }

    private void advance() {
        if (currentIndex < tokens.size() - 1) {
            currentIndex++;
        }
    }

    private boolean match(String value) {
        return current().getValue().equals(value);
    }

    private boolean isRelationalOp(String op) {
        return op.equals("<") || op.equals(">") || op.equals("==") ||
                op.equals("!=") || op.equals("<=") || op.equals(">=");
    }

    private void expect(String value) {
        if (!match(value)) {
            throw new RuntimeException("Expected '" + value + "' but found '" + current().getValue() + "'");
        }
        advance();
    }

    public AST.ASTNode buildAST() {
        return parseProgram();
    }

    private AST.ProgramNode parseProgram() {
        AST.ClassNode classNode = parseClass();
        return new AST.ProgramNode(classNode);
    }

    private AST.ClassNode parseClass() {
        expect("class");
        String className = current().getValue();
        advance();
        expect("{");

        AST.ClassNode classNode = new AST.ClassNode(className);

        while (!match("}") && current().getType() != Token.TokenType.EOF) {
            AST.ASTNode member = parseMember();
            if (member != null) {
                classNode.addMember(member);
            }
        }

        expect("}");
        return classNode;
    }

    private AST.ASTNode parseMember() {
        String type = current().getValue();
        advance();
        String name = current().getValue();
        advance();

        if (match(";")) {
            advance();
            return new AST.VarDeclNode(type, name);
        } else if (match("(")) {
            advance();
            AST.MethodDeclNode method = new AST.MethodDeclNode(type, name);

            if (!match(")")) {
                do {
                    if (match(",")) advance();
                    String paramType = current().getValue();
                    advance();
                    String paramName = current().getValue();
                    advance();
                    method.addParameter(new AST.VarDeclNode(paramType, paramName));
                } while (match(","));
            }

            expect(")");
            AST.BlockNode body = parseBlock();
            method.setBody(body);

            return method;
        }

        return null;
    }

    private AST.BlockNode parseBlock() {
        expect("{");
        AST.BlockNode block = new AST.BlockNode();

        while (!match("}") && current().getType() != Token.TokenType.EOF) {
            AST.ASTNode stmt = parseStatement();
            if (stmt != null) {
                block.addStatement(stmt);
            }
        }

        expect("}");
        return block;
    }

    private AST.ASTNode parseStatement() {
        if (match("return")) {
            return parseReturn();
        } else if (match("int") || match("void")) {
            String type = current().getValue();
            advance();
            String name = current().getValue();
            advance();
            expect(";");
            return new AST.VarDeclNode(type, name);
        } else if (current().getType() == Token.TokenType.ID) {
            String id = current().getValue();
            advance();

            if (match("=")) {
                advance();
                AST.ASTNode expr = parseExpression();
                expect(";");
                return new AST.AssignNode(id, expr);
            } else if (match("(")) {
                advance();
                AST.CallNode call = new AST.CallNode(id);

                if (!match(")")) {
                    do {
                        if (match(",")) advance();
                        AST.ASTNode arg = parseExpression();
                        call.addArgument(arg);
                    } while (match(","));
                }

                expect(")");
                expect(";");
                return call;
            }
        }

        return null;
    }

    private AST.ReturnNode parseReturn() {
        expect("return");

        if (match(";")) {
            advance();
            return new AST.ReturnNode(null);
        }

        AST.ASTNode expr = parseExpression();
        expect(";");
        return new AST.ReturnNode(expr);
    }

    private AST.ASTNode parseExpression() {
        // Expr -> Term ('+' Term | '-' Term | '<' Term | '>' Term | ...)*
        AST.ASTNode left = parseTerm();

        while (match("+") || match("-") || isRelationalOp(current().getValue())) {
            String op = current().getValue();
            advance();
            AST.ASTNode right = parseTerm();
            left = new AST.BinaryOpNode(op, left, right);
        }

        return left;
    }

    private AST.ASTNode parseTerm() {
        AST.ASTNode left = parseFactor();

        while (match("*") || match("/")) {
            String op = current().getValue();
            advance();
            AST.ASTNode right = parseFactor();
            left = new AST.BinaryOpNode(op, left, right);
        }

        return left;
    }

    private AST.ASTNode parseFactor() {
        if (current().getType() == Token.TokenType.NUMBER) {
            String value = current().getValue();
            advance();
            return new AST.NumberNode(value);
        } else if (current().getType() == Token.TokenType.ID) {
            String id = current().getValue();
            advance();

            if (match("(")) {
                advance();
                AST.CallNode call = new AST.CallNode(id);

                if (!match(")")) {
                    do {
                        if (match(",")) advance();
                        AST.ASTNode arg = parseExpression();
                        call.addArgument(arg);
                    } while (match(","));
                }

                expect(")");
                return call;
            }

            return new AST.IdentifierNode(id);
        } else if (match("(")) {
            advance();
            AST.ASTNode expr = parseExpression();
            expect(")");
            return expr;
        }

        return null;
    }
}